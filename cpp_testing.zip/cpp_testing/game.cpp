#include <SFML\Graphics.hpp>
#include <SFML\Window.hpp>
#include <SFML\System.hpp>
#include <SFML\Audio.hpp>
using namespace sf;
using namespace std;

int main(){
	
    RenderWindow window(VideoMode(2000, 1000), "Game", Style::Default);
    window.setFramerateLimit(60);
    
	Texture ship_t;
	if (!ship_t.loadFromFile("ship.jpg")){
		return 0;
	}
	
	Texture enemy_t1, enemy_t2;
	if (!enemy_t1.loadFromFile("enemy1.jpg")) return 0;
	if (!enemy_t2.loadFromFile("enemy2.jpg")) return 0;
	
	Sprite ship, enemy;
	ship.setTexture(ship_t);
	ship.setPosition(1000.f, 920.f);
	enemy.setTexture(enemy_t1);
	enemy.setPosition(100.f, 100.f);
	
	Music music;
    if (!music.openFromFile("bgm.ogg")){
        return 0;
    }
	music.setVolume(1.f);
	music.setLoop(true);
    music.play();
    
    while (window.isOpen()){
        Event event;
        while (window.pollEvent(event)){
            if (event.type == Event::Closed){
				window.close();
			}
            
            if (Keyboard::isKeyPressed(Keyboard::Left)) ship.move(-10.f, 0.f);
			if (Keyboard::isKeyPressed(Keyboard::Right)) ship.move(10.f, 0.f);
        }
		
		//Draw
        window.clear(Color::Black);
        window.draw(ship);
        
        window.display();
    }

    return 0;
}
